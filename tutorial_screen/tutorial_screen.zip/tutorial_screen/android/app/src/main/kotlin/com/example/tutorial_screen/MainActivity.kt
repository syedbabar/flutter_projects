package com.example.tutorial_screen

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
